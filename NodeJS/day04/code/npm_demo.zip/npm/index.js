var md5 = require('md5');

let ret = md5('你要加密的数据') // 会返回一个加密结果
console.log(ret);