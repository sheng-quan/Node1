// 初始化项目   yarn init -y
// 安装 express    yarn add express

//1、引入express
const express = require("express");
//2、创建app对象(项目对象)，它就是项目最大的这个对象
const app = express();

//4、处理请求   // 第一个参数是  请求路径， 第二个参数是针对这个路径的处理函数
app.get("/", (req, res)=>{
    //这个函数有两个形参
    //第一个形参req是请求对象(跟请求相关的数据，需要用它)
    //第二个参数res是响应对象(和响应相关的工作，需要它)

    // 响应一个字符串给浏览器
    res.send("hello express 框架！");
    
})

//3、监听是否有请求
app.listen(3000,()=>{
    //这里的代码会在服务器启动的时候执行1次
    console.log("Express web server is listen at 3000 port!");
    
})