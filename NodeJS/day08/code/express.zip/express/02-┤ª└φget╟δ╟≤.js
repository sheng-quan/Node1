const express = require("express");
const fs = require("fs");
const path = require("path");


const app = express();



app.get("/", (req, res)=>{
    console.log("首页的内容");
    res.send("首页");
})

// 目前先由app对象来处理，后面交给router来处理
app.get("/register",(req,res)=>{
    // 获取文件路径
    let filePath = path.join(__dirname, "views", "register.html")
    // 读取文件内容
    let content = fs.readFileSync(filePath, "utf-8");
    res.send(content);  // 返回一个register.html页面给浏览器
})

app.listen(3000, ()=>{
    console.log("Express web server is listen at 3000 port!");
})
