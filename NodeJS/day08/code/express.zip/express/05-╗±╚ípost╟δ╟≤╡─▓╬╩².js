const express = require("express");
const fs = require("fs");
const path = require("path");
// 1、引入body-parser
const bodyParser = require("body-parser");
const app = express();


// 2、把bodyParser添加到项目中, 把bodyParser注册到app下(让它在我们app下能够使用)
app.use(bodyParser.urlencoded({ extended: false }))  //false接收的值为字符串或者数组，true则为任意类型
// parse application/json    
app.use(bodyParser.json())   // 解析json格式


app.get("/", (req, res)=>{
    console.log("首页的内容");
    res.send("首页");
})

// 目前先由app对象来处理，后面交给router来处理
app.get("/register",(req,res)=>{
    // 获取文件路径
    let filePath = path.join(__dirname, "views", "register.html")
    // 读取文件内容
    let content = fs.readFileSync(filePath, "utf-8");
    res.send(content);
})

app.post("/register", (req, res)=>{
    // 点击提交按钮，触发这个请求
    // 可以在这个接口中处理 post请求了。

    // 一般post提交过来之后，后端需要获取提交过来的参数。
    // 获取用户填写的数据，也叫请求参数

    // 3、获取参数，用过 req.body来获取
    console.log(req.body);
    
    let {username, email, password, repwd} = req.body
    console.log(username, email, password, repwd);
    

    // 业务逻辑：
    // 获取参数
    // 校验参数，是不是符合规则， 判空
    // 查询数据库 看看用户名是否被注册
    // ....


    res.send("post ok!")
})

app.listen(3000, ()=>{
    console.log("Express web server is listen at 3000 port!");
})
