const express = require("express");
const fs = require("fs");
const path = require("path");
// 1、引入body-parser
const bodyParser = require("body-parser");
const app = express();


// 2、把bodyParser添加到项目中, 把bodyParser注册到app下(让它在我们app下能够使用)
app.use(bodyParser.urlencoded({ extended: false }))  //false接收的值为字符串或者数组，true则为任意类型
// parse application/json    
app.use(bodyParser.json())   // 解析json格式


app.get("/", (req, res)=>{
    console.log("首页的内容");
    res.send("首页");
})

app.all("/register", (req,res)=>{

    // 先获取请求方式， 根据请求方式执行对应的代码处理
    console.log(req.method);
    if(req.method === "GET"){
        let filePath = path.join(__dirname, "views", "register.html")
        // 读取文件内容
        let content = fs.readFileSync(filePath, "utf-8");
        res.send(content);   // 返回注册页面
    }else if(req.method === "POST"){
        // 3、获取参数，用过 req.body来获取
        console.log(req.body);
        let {username, email, password, repwd} = req.body
        console.log(username, email, password, repwd);

        res.redirect("/login"); 
    }

})




app.get("/login", (req, res)=>{
    // 获取文件路径
    let filePath = path.join(__dirname, "views", "login.html")
    // 读取文件内容
    let content = fs.readFileSync(filePath, "utf-8");
    res.send(content);   // 返回注册页面
})


app.listen(3000, ()=>{
    console.log("Express web server is listen at 3000 port!");
})
