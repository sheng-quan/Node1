
const express = require("express");
const path = require("path");
const fs = require("fs");
const app = express();

// 在一个项目中，会有一个静态资源文件夹， 
app.use(express.static("public"))   // 设置在public下查找资源(以public为根去找静态资源)
//http://127.0.0.1:3000/images/01.jpg

// 在静态资源的路径下加一个前缀（了解）
// app.use("/static", express.static("public")) 
//http://127.0.0.1:3000/static/images/01.jpg

app.get("/", (req, res)=>{
    res.send("hello express 框架！");
    
})

app.get("/login", (req, res)=>{
    // 获取文件路径
    let filePath = path.join(__dirname, "views", "login.html")
    // 读取文件内容
    let content = fs.readFileSync(filePath, "utf-8");
    res.send(content);   // 返回登录页面
})


app.listen(3000,()=>{
    console.log("Express web server is listen at 3000 port!");
    
})