
const express = require("express");
const path = require("path");
const app = express();


// 这四句代码， 模板引擎的初始化工作
// 引入express-art-template, 使用对应的引擎
app.engine('html', require('express-art-template'));
//  项目环境的设置：
//  生产环境(线上)  production
//  开发环境  development
app.set('view options', {
    debug: process.env.NODE_ENV !== 'production'
});
// 设置在哪一个目录下查找模板文件
app.set('views', path.join(__dirname, 'views'));
// 设置模板的后缀名为html
app.set('view engine', 'html');



app.get("/", (req, res)=>{

    // 我们可以在接口中查询数据库，得到数据之后，传递给模板，展示在页面上

    let data = {
        num1: 70,
        num2: 30,
        user:{
            name:"张三",
            age:18,
            email:"zhangsan@163.com"
        },
        books:["《西游记》", "《三国演义》","《红楼梦》", "《水浒传》"],
    }

    // res.send("hello express 框架！");
    res.render("index", data);   // 返回index页面给浏览器, 并把data传递到模板中
})

app.listen(3000,()=>{
    console.log("Express web server is listen at 3000 port!");
    
})