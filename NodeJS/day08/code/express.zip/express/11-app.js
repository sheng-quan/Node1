const express = require("express");

const bodyParser = require("body-parser");
const passportRouter = require("./routes/passport");  //引入passport里面的路由对象
const indexRouter = require("./routes/index");  //引入passport里面的路由对象
const app = express();




app.use(bodyParser.urlencoded({ extended: false }))  //false接收的值为字符串或者数组，true则为任意类型
// parse application/json    
app.use(bodyParser.json())   // 解析json格式


// ！！！把路由对象注册到app下
app.use(passportRouter)
app.use(indexRouter)



app.listen(3000, ()=>{
    console.log("Express web server is listen at 3000 port!");
})
