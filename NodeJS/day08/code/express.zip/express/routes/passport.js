const express = require("express")
const fs = require("fs");
const path = require("path");


const router = express.Router();

// 目前先由app对象来处理，后面交给router来处理
router.get("/register",(req,res)=>{
    // 获取文件路径
    let filePath = path.join(__dirname, "../views", "register.html")
    // 读取文件内容
    let content = fs.readFileSync(filePath, "utf-8");
    res.send(content);   // 返回注册页面

})



router.post("/register", (req, res)=>{
    // 点击提交按钮，触发这个请求
    // 可以在这个接口中处理 post请求了。

    // 一般post提交过来之后，后端需要获取提交过来的参数。
    // 获取用户填写的数据，也叫请求参数

    // 3、获取参数，用过 req.body来获取
    console.log(req.body);
    
    let {username, email, password, repwd} = req.body
    console.log(username, email, password, repwd);
    

    res.redirect("/login"); //重定向到(跳转到) /login接口，交给 .get("/login")去处理
})



router.get("/login", (req, res)=>{
    // 获取文件路径
    let filePath = path.join(__dirname, "../views", "login.html")
    // 读取文件内容
    let content = fs.readFileSync(filePath, "utf-8");
    res.send(content);   // 返回注册页面
})


module.exports = router