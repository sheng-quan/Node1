// pathinfo参数， 又叫pathname参数
const express = require("express");
const path = require("path");

const app = express();

app.engine('html', require('express-art-template'));
app.set('view options', {
    debug: process.env.NODE_ENV !== 'production'
});
app.set('views', path.join(__dirname, 'views'));
app.set('view engine', 'html');


app.get("/list", (req, res)=>{
    res.render("list")
})


app.get("/detail/:id/:type", (req, res)=>{

    // 在这里需要知道要获取的是那一篇文章的详情， 
    // 所以在请求这个detail页面的时候需要传递参数，传递这篇新闻的id
    console.log(req.params);
    console.log(req.params.id);
    console.log(req.params.type);
    
    // 再去根据这个id去查询数据库，，获取这篇文章的内容，传到模板里面去

    res.send("detail详情页"+req.params.id)
})


app.listen(3000, ()=>{
    console.log("服务器已经启动在3000端口！");
})
