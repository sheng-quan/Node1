
const express = require("express");
// 1、 引入art-template
const template = require("art-template");
const path = require("path");

const app = express();

app.engine('html', require('express-art-template'));
app.set('view options', {
    debug: process.env.NODE_ENV !== 'production'
});
app.set('views', path.join(__dirname, 'views'));
app.set('view engine', 'html');

// 2、书写过滤器函数
/*
template.defaults.imports.过滤器名字 = function(value){

    return 过滤后的数据
};

*/
template.defaults.imports.timestamp = function(value){
    //value接收  |  前面的那个数据
    return value * 1000   // 返回出过滤后的数据
};
// 3、在模板中使用过滤器函数  {{ 数据 |  过滤器名字}}
app.get(("/"), (req,res)=>{

    let data = {
        num: 20
    }
    res.render("index", data)
})



app.listen(3000, ()=>{
    console.log("服务器已经启动在3000端口！");
})
