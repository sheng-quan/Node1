
const express = require("express");
const cookieParser = require("cookie-parser");

const app = express();

app.use(cookieParser());



app.get("/set_cookie", (req, res)=>{

    /*设置cookie */
    res.cookie("name", "nodejs", {maxAge: 1000 * 60 * 60});    // 过期时间，单位是毫秒    1s等于1000ms
    res.cookie("age", 11);

    res.send("设置cookie信息");
})




app.get("/get_cookie", (req, res)=>{

    /*获取cookie */
    console.log(req.cookies);
    
    let name = req.cookies.name;
    let age = req.cookies["age"];

    res.send(`获取到的cookie信息为：${name}, ${age}`);
})



app.listen(3000, ()=>{
    console.log("服务器已经启动在3000端口！");
})
