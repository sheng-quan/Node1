const express = require("express");
//引入
const cookieSession = require("cookie-session");
const app = express();

//注册到app下
app.use(cookieSession({
    name:"my_session",   //作为cookie中的键
    keys:["#%^%$%^RGFDHHGFRFERTERT$%^%$^%$&THGFGHFDFS"],   // 用来生成cookie中的值，即生成数据的标识
    maxAge: 1000 * 60 * 60 * 24 * 2 
}))


app.get("/set_session",(req,res) =>{
    // 设置session信息
    req.session["name"] = "nodejs_session";
    req.session["age"] = 12;
    res.send("设置了session数据");
})


app.get("/get_session",(req,res) =>{
    // 获取session信息
    let name = req.session["name"];
    let age = req.session["age"];
    res.send(`获取到session数据为：${name}，${age}`);
})


app.listen(3000, ()=>{
    console.log("服务器已经启动在3000端口！");
})
