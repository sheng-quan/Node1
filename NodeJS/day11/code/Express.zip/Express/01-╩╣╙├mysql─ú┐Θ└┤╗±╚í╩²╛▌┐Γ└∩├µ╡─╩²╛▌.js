const express = require("express");
const db = require("./db/db");
const app = express();


app.get("/get_data", (req,res)=>{

    // 查询数据库，返回到浏览器
    db.query("select * from students where id = 10", (err, data)=>{

        if(err){
            console.log(err);
            res.send("数据库查询出错");
            return
        }
        console.log(data); // data就是在数据库中查出来的数据
        res.send(data);   // 在页面上展示这个data数据
    })
    // res.send("hello world")


})


app.listen(3000, ()=>{
    console.log("服务器已经启动，端口为：3000");
})