const express = require("express");
const db = require("./db/nodejs-orm");
const app = express();


app.get("/get_data", (req,res)=>{

    // 使用orm查询数据库
    // 创建模型： 需要操作哪一个数据库表？
    let Students = db.model("students");     //db.model("表名")
    Students.find(["name", "age"],(err, data)=>{

        res.send(data);
    })

})


app.listen(3000, ()=>{
    console.log("服务器已经启动，端口为：3000");
})