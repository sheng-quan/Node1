const express = require("express");
const db = require("./db/nodejs-orm");
const app = express();


app.get("/get_data", (req,res)=>{

    // 使用orm查询数据库
    // 创建模型： 需要操作哪一个数据库表？
    let Students = db.model("students");     //db.model("表名")
    // Students.find((err, data)=>{   // 直接写回调函数的，就是查询所有

    //     res.send(data);
    // })

    //第一参数是数组, 查询指定字段名,数组中每一个元素就是字段名
    // Students.find(["id","name", "age"], (err, data)=>{  
    //     res.send(data)
    // })

    //第一个参数是字符串，相当于where后面所写的条件
    // Students.find("name='小月月'", (err, data)=>{  
    //     res.send(data)
    // })


    // 分页查询
    // number: 第几页
    // count: 每页条数？
    // where: 可选属性。可写可不写。值是字符串。
    // Students.limit({number:2, count:2},(err,data)=>{

    //     res.send(data)
    // })


    // 扩展
    Students.find({where:"age>18", arr:["name", "age"]}, (err, data)=>{  
        res.send(data)
    })

})


app.listen(3000, ()=>{
    console.log("服务器已经启动，端口为：3000");
})