const express = require("express");
const db = require("./db/nodejs-orm");
const app = express();


app.get("/get_data", (req,res)=>{

    // 增加单条数据
    let Students = db.model("students");
    // Students.insert({name:"赵云", age:20},(err, data)=>{

    //     console.log(data);
    //     res.send(data);

    //     /*
        
    //     {
    //         fieldCount: 0,
    //         affectedRows: 1,
    //         insertId: 15,     是新增的这条记录的id值
    //         serverStatus: 2,
    //         warningCount: 0,
    //         message: "",
    //         protocol41: true,
    //         changedRows: 0
    //     }
    //     */


    // })



    // 增加多条数据
    Students.insert([{name:"刘备"}, {name:"张飞"}, {name:"关羽"}], (err, result)=>{
        console.log(result);
        
        res.send("添加成功！")
    })

    


})


app.listen(3000, ()=>{
    console.log("服务器已经启动，端口为：3000");
})