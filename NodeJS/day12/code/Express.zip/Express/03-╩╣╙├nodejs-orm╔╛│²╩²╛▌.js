const express = require("express");
const db = require("./db/nodejs-orm");
const app = express();


app.get("/get_data", (req,res)=>{


    let Students = db.model("students");
    
    // 物理删除
    // 删除单条记录
    // Students.delete("id=21", (err, retult)=>{
    //     console.log(retult);
    // })

    // 清空表格
    // Students.delete((err, retult)=>{
    //     console.log(retult);
    // })

})


app.listen(3000, ()=>{
    console.log("服务器已经启动，端口为：3000");
})