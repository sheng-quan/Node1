const express = require("express");
const db = require("./db/nodejs-orm");
const app = express();


app.get("/get_data", (req,res)=>{


    let Students = db.model("students");
    
    // 修改数据
    // 只传了一个对象，表示把所有记录都修改age字段为30
    // Students.update({age: 30},(err,result)=>{
    //     console.log(result);
    // })


    // 回调函数前面有两个参数，第一个参数是条件(where 后面的), 第二个参数是对象，是要修改的字段和值
    Students.update("id=1", {age: 18}, (err, result)=>{
        console.log(result);
    })
})  


app.listen(3000, ()=>{
    console.log("服务器已经启动，端口为：3000");
})