const express = require("express");
const db = require("./db/nodejs-orm");
const app = express();


app.get("/get_data", (req,res)=>{


    let Students = db.model("students");
    Students.sql("select * from students limit 10", (err, data)=>{
        res.send(data);
    })
    
})  


app.listen(3000, ()=>{
    console.log("服务器已经启动，端口为：3000");
})