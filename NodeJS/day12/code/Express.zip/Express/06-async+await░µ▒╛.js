const express = require("express");
const db = require("./db/nodejs-orm");
const app = express();


app.get("/get_data", (req,res)=>{

    (async function(){

        // 涉及到查询数据库操作的。
        let Students = db.model("students");
        // result 到底接收了什么？？
        // 如果查询成功： result 接收data
        // 如果查询失败： result 接收err
        let result = await new Promise((resolve, reject)=>{
            Students.find("age<20", (err, data)=>{
                if(err)reject(err);
                resolve(data);
            })  
        })




        res.send(result);




    })();
})  


app.listen(3000, ()=>{
    console.log("服务器已经启动，端口为：3000");
})