const express = require("express");
const db = require("./db/nodejs-orm");
const app = express();


app.get("/get_data", (req,res)=>{

    (async function(){

        // 涉及到查询数据库操作的。
        let Students = db.model("students");
        let result
        try{
            result = await new Promise((resolve, reject)=>{
                Students.find("age<20", (err, data)=>{
                    if(err)reject(err);
                    resolve(data);
                })  
            })   
        }catch(err){
            console.log(err); // 在后端打印异常
            res.send({errMsg: "数据库查询出错"})  // 通知前端出现异常
            return
        }
    

        res.send(result);

    })();
})  


app.listen(3000, ()=>{
    console.log("服务器已经启动，端口为：3000");
})