const express = require("express");
const handleDB = require("./db/handleDB");
const app = express();



app.get("/get_data", (req,res)=>{

    (async function(){

        // 涉及到查询数据库操作的。
        // 要操作哪一个表，   
        // 要怎么操作   增删改查这些方法名
        // let result = await handleDB(res, "students", "update", "数据库修改出错","id=12",{age:20});
        // let result = await handleDB(res, "students", "insert", "数据库插入数据出错", {name:"马超"});
        
        // 以后数据库操作直接调用handleDB这个函数
        let result = await handleDB(
            res, 
            "students", 
            "insert", 
            "数据库插入数据出错", 
            {name:"马超"}
        );
        
        // 封装, 调用一个方法

        
        res.send(result);

    })();
})  


app.listen(3000, ()=>{
    console.log("服务器已经启动，端口为：3000");
})