module.exports = {
    session_key: "$%$&^%&THGFFDGHJHGE%%$Y&%^HGFF#$G%G$FF#F$#G%H^%H^%H%^",
    password_salt: "$#^%^%$RFGHG$$&&%^#$#T",
    jwt_salt:"$#^%^*%&%FDGFGDJ$%$HH&&%%%^%$&^$$^*"
}