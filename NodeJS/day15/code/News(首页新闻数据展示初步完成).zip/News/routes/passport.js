const express = require("express");
const md5 = require("md5");
const Captcha = require("../utils/captcha");
const handleDB = require("../db/handleDB");
const keys = require("../keys");
const jwt = require("jsonwebtoken")
const router = express.Router();



router.get("/passport/image_code/:float", (req, res)=>{
    let captchaObj = new Captcha();
    let captcha = captchaObj.getCode();

    // captcha.text    // 图片验证码文本， 
    // captcha.data    // 图片验证码图片内容信息 
    // 保存图片验证码文本到session中
    req.session["ImageCode"] = captcha.text;
    console.log(req.session);   
    

    // 图片， <img src="路径" alt=""/>
    res.setHeader('Content-Type', 'image/svg+xml'); 
    res.send(captcha.data);
})


router.post("/passport/register",(req, res)=>{

    (async function(){
        // console.log("/passport/register");
        // 分析完成注册功能需要做哪些事情(后端实现接口要尽可能严谨)

        // 1、获取post参数，判空
        let {username, image_code, password, agree} = req.body
        // 如果四个中有一个是空的(flase),就要return
        if(!username || !image_code || !password || !agree){  //缺少必须要传的参数
            res.json({errmsg:"缺少必传参数"})
            return
        }
        // 2、验证用户输入的图片验证码是否正确，不正确就return
        // 拿着用户填写的image_code和session中的req.session["ImageCode"]进行对比
        if(image_code.toLowerCase() !== req.session["ImageCode"].toLowerCase()){
            res.send({errmsg:"验证码填写错误"})
            return
        }
      
        // 3、查询数据库， 看看用户名是不是被注册了
        let result = await handleDB(res, "info_user", "find", "数据库查询出错", `username="${username}"`)
        // console.log("result为：", result);
        
        // 有这个用户result是一个数组 [{字段名1:值1}]
        // 没有的话result是一个空数组 []

        // 4、如果已经存在，返回用户名已经被注册，并return
        // if(已经存在){
        // if(result.length>0){
        if(result[0]){
            res.send({errmsg:"用户名已经被注册"})
            return 
        }
        // 5、不存在，就在数据库中新增加一条记录
        let result2 = await handleDB(res, "info_user", "insert", "数据库插入数据出错", {
            username,
            password_hash:md5(md5(password)+keys.password_salt),
            nick_name:username,
            last_login:new Date().toLocaleString()
        })
        //result2.insertId   插入数据的时候，自动生成的这个id值

        // 6、保持用户的登录状态
        req.session["user_id"] = result2.insertId

        // 7、返回注册成功给前端
        res.send({errno:'0', errmsg:"注册成功"})
    })();
})

router.post("/passport/login", (req,res)=>{

    (async function(){

        //1、获取post请求参数，判空
        let {username, password} = req.body
        if(!username || !password ){  //缺少必须要传的参数
            res.json({errmsg:"缺少必传参数"})
            return
        }
        //2、查询数据库，验证用户名是不是已经注册了
        let result = await handleDB(res, "info_user", "find", "数据库查询出错", `username="${username}"`);
        // result可能出现的两种情况：[{...}]    [ ]
        //3、如果没有注册，返回用户名未注册， return
        if(!result[0]){
            res.send({errmsg:"用户名未注册， 登录失败"})
            return
        }

        // console.log("result为：", result);
        
        //4、校验 密码是不是正确？如果不正确， 就return
        if(md5(md5(password)+keys.password_salt) !== result[0].password_hash){
            res.send({errmsg:"用户名或者密码不正确，登录失败"})
            return
        }
        //5、保持用户登录状态
        req.session["user_id"] = result[0].id
        //设置最后一次登录时间 last_login字段
        //本质是在修改字段
        await handleDB(res, "info_user", "update", "数据库修改出错", `id=${result[0].id}`, {last_login:new Date().toLocaleString()})
        //6、返回登录成功给前端
        res.send({errno:"0", errmsg:"登录成功"});

    })();
})


router.post("/passport/logout", (req, res)=>{
    // 退出登录的操作
    // 退出登录实际上是删除session中的user_id
    delete req.session["user_id"];
    res.send({errmsg:"退出登录成功"});
})

// 以下这两个接口和本项目《经济新闻项目》没有关系
// jwt的生成和验证
// 生成jwt_token
router.get("/passport/token",(req, res)=>{

    //参数...
    const token = jwt.sign({id:1, username:"zhangsan"}, keys.jwt_salt, {expiresIn:20})
    
    res.send({
        errmsg:"success!",
        errno:"0",
        reason:"登录请求",
        result:{
            token
        }
    })

})

router.get("/passport/transfer",(req, res)=>{


    //验证jwt_token是否有效
    const token = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZCI6MSwidXNlcm5hbWUiOiJ6aGFuZ3NhbiIsImlhdCI6MTU5MDEzNjA5MCwiZXhwIjoxNTkwMTM2MTEwfQ.Esb9urOqHL6movy_2rpXSlAqSMc5ctdUUun4MidMP0k"
    try{
        var userData = jwt.verify(token, keys.jwt_salt);   //获取token中的数据(用户信息)
    }catch(e){
        console.log("无效的jwt_token")
        res.send("无效的jwt_token")
        return
    }

    // 转账业务...
    res.send("正在执行转账业务....")
})


module.exports = router