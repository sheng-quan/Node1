const express = require("express");
const handleDB = require("../db/handleDB");
const common = require("../utils/common");
const router = express.Router();


router.get("/news_detail/:news_id", (req,res)=>{
    (async function(){
        // 在获取登录用户的信息
        let userInfo =  await common.getUser(req,res);  // [{...}]     [] 

        // 右侧点击排行的查询
        let result3 = await handleDB(res, "info_news", "find", "查询数据库出错", "1 order by clicks desc limit 6");

        let {news_id} = req.params;
        // 左侧新闻内容的查询
        let newsResult = await handleDB(res, "info_news", "find", "查询数据库出错", `id=${news_id}`);
        // newsResult   [{ }]   []
        // console.log(newsResult[0]);  //[{ }]

        // 确保数据有id为news_id这篇新闻，才可以继续往下操作
        if(!newsResult[0]){   // 如果没有这篇新闻，就返回404页面
            common.abort404(req,res);
            return
        }

        
        // 点击数就+1
        newsResult[0].clicks+=1
        await handleDB(res, "info_news", "update", "数据库更新出错", `id=${news_id}`, {clicks:newsResult[0].clicks})




        let data = {
            user_info:userInfo[0]?{
                nick_name: userInfo[0].nick_name,
                avatar_url: userInfo[0].avatar_url
            }:false,
            newsClick:result3,
            newsData:newsResult[0]
        }

        res.render("news/detail", data); 

    })();
})

module.exports = router