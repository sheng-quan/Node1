const express = require("express");
const handleDB = require("../db/handleDB");
const common = require("../utils/common");
require("../utils/filter");

const router = express.Router();


router.get("/", (req,res)=>{
    (async function(){
        // 访问首页， 处理右上角是否登录展示问题
        // 判断是否登录
        // 从session中获取user_id
        // 在获取登录用户的信息
        let userInfo =  await common.getUser(req,res);  // [{...}]     [] 
        
        //-------------------------------------------------------------------
        // 展示首页头部分类信息
        // 查询数据库，查看分类信息？ 查表info_category
        let result2 = await handleDB(res, "info_category", "find", "查询数据库出错", ["name"]);
        // [{name:最新},{name:xxx}, ...]

        // 展示首页右侧点击排行的效果
        // 查询数据 排序 取前6条
        // let result3 = await handleDB(res, "info_news", "sql", "查询数据库出错", "select * from info_news order by clicks desc limit 6");
        let result3 = await handleDB(res, "info_news", "find", "查询数据库出错", "1 order by clicks desc limit 6");
        // select * from info_news where 1 order by clicks desc limit 6



        //可以把用户信息传递到模板中去
        let data = {
            user_info:userInfo[0]?{
                nick_name: userInfo[0].nick_name,
                avatar_url: userInfo[0].avatar_url
            }:false,
            category:result2,
            newsClick:result3  // [{},{}]
        }
        res.render("news/index", data);
    })();
})

// Restful风格的接口 (和news项目没有关系)
router.get("/category",(req, res)=>{
    (async function(){
        let result2 = await handleDB(res, "info_category", "find", "查询数据库出错", ["name"]);
        res.send({
            status:"0",
            reason:"新闻分类的请求",
            data:result2
        })
    })();
})



router.get("/news_list", (req, res)=>{
    (async function(){
        // 1、获取参数     cid(新闻分类id)      page(当前页数)   per_page(每页条数)
        let {cid=1, page=1, per_page=5} = req.query;   // 分别给参数设置默认值

        // res.send({cid, page, per_page})
        // 2、查询数据库， 根据以上3个参数， 获取前端需要的这些数据
        // where 可选  number当前页数     count 每页条数
        //  select * from info_news where 1 order by create_time desc;
        // 如果cid为1的话 ，category_id=${cid}可以不用写，换成1.  表示查全部

        // 如果cid为1的话 ，where:`1 order by create_time desc`, 
        // 如果cid不是1的话 ，where:`category_id=${cid} order by create_time desc`, 

        let wh = cid==1?"1":`category_id=${cid}`;
        
        let result = await handleDB(res, "info_news", "limit", "数据库查询出错", 
            {where: `${wh} order by create_time desc`, 
            number:page,
            count:per_page
        });  // 这个结果是一个数组  [{}, {}, {}, ...]


        // 求总页数totalPage
        // 总页数 = 总条数/每页有多少条    123.6      结果应该向上取整  Math.ceil()
        let result2 = await handleDB(res, "info_news", "sql", "数据库查询出错", "select count(*) from info_news where " + wh)  // 计算总条数
        // console.log(result2);  // [ RowDataPacket { 'count(*)': 1155 } ]
        
        let totalPage = Math.ceil(result2[0]['count(*)']/per_page)

        // 3、把查询到的新闻数据结果返回到前端    
        res.send({
            newsList: result,
            totalPage,
            currentPage:Number(page)
        })
    })();
    

})






// 以下是测试代码
// router.get("/get_cookie", (req,res)=>{
//     // 测试获取cookie
//     res.send("cookie中name的值为："+req.cookies["name"]);
// })
// router.get("/get_session", (req,res)=>{
//     // 测试获取session
//     res.send("cookie中my_session中的age的值为："+req.session["age"]);
// })


// router.get("/get_data", (req,res)=>{
//     // 测试查询数据库
//     (async function(){
//         let result = await handleDB(res, "info_category", "find", "数据库查询出错");
//         res.send(result);    
//     })();
// })


module.exports = router