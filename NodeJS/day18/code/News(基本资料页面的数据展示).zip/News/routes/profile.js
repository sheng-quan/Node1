const express = require("express");
const handleDB = require("../db/handleDB");
const common = require("../utils/common");
const router = express.Router();

router.get("/profile", (req, res)=>{
    (async function(){

        let userInfo = await common.getUser(req, res);
        if(!userInfo[0]){
            // 没有登录，就重定向到首页
            res.redirect("/");
        }




        let data = {
            user_info:{
                nick_name: userInfo[0].nick_name,
                avatar_url: userInfo[0].avatar_url?userInfo[0].avatar_url:"/news/images/worm.jpg"
            }
        }
        res.render("news/user", data)
    })();
    
})

// 展示基本信息页面，以及处理基本信息的POST提交
router.all("/user/base_info",(req, res)=>{
    (async function(){
        //获取用户登录信息，获取不到就重定向到首页
        let userInfo = await common.getUser(req, res);
        if(!userInfo[0]){
            res.redirect("/");
        }

        if(req.method==="GET"){

            let data = {
                nick_name:userInfo[0].nick_name,
                signature:userInfo[0].signature,
                gender:userInfo[0].gender?userInfo[0].gender:"WOMAN"
            }

            res.render("news/user_base_info", data)
        }


    })();
})

module.exports = router