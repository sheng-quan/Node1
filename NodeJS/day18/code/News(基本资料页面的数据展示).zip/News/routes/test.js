const express = require("express");

const Base64 = require("js-base64").Base64;
const md5 = require("md5");
const router = express.Router();

router.get("/test_base64", (req, res)=>{


    // let ret = Base64.encode('Man'); // 编码      
    let ret = Base64.decode('TWFu');   // 解码
    res.send(ret)
})

router.get("/test_md5", (req, res)=>{

    // 双重md5加盐加密的处理方式。
    let ret = md5(md5("hello")+"%&%$%$%%&^&%$%TTYRTY#$TT%$$#FF#F%HF@F");   //盐
   
    res.send(ret)
})


module.exports = router