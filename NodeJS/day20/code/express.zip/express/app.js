// 入口文件
const express = require("express");
const router = express.Router();
const app = express();



function func1(req,res, next){
    console.log("func1"); // 1
    next()
    console.log(11111111);  // 4
}

router.get("/get_data",(req, res,next)=>{
    console.log("get_data");   //2
    // res.send("get_data");
    next()
    console.log(22222222);   // 3
})



function func2(req,res, next){
    console.log("func2");   // 5
}
app.use(func1,router, func2)

app.listen(3008, ()=>{
    console.log(`服务器已经启动，端口为：3008`);
})