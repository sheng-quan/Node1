// 入口文件
const express = require("express");
const router = express.Router();
const app = express();



router.get("/get_data",(req, res, next)=>{
    console.log("111111111");
    next()
    console.log("22222222");
},(req, res,next)=>{
    console.log("333333333");  
    next()
    console.log("444444444");   
},(req, res, next)=>{
    console.log("5555555555");  
})

/*
111111111
333333333
5555555555
444444444
22222222
*/

app.use(router)

app.listen(3008, ()=>{
    console.log(`服务器已经启动，端口为：3008`);
})