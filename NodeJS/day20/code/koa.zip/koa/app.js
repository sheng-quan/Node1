const Koa = require('koa');
const app = new Koa();

app.use(async ctx => {   //  req, res     context上下文

    console.log(ctx.request.url);
    console.log(ctx.req.url);
    console.log(ctx.url);
    
    console.log(ctx.req.method);
    
    ctx.body = 'Hello World';
});

app.listen(3000, ()=>{
    console.log("server is running at port 3000");
});