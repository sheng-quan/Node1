const Koa = require('koa');
const Router = require('koa-router');
const handleDB = require('./db/handleDB');
const app = new Koa();
const router = new Router();


router.get("/get_data", async ctx => {   //  req, res     context上下文

    let ret =  await handleDB(ctx.res, "info_user", "find", "数据库查询出错")
    ctx.body = ret
});


app.use(router.routes());

app.listen(3000, ()=>{
    console.log("server is running at port 3000");
});